<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('query', function (Blueprint $table) {
            $table->id();
            $table->foreignId('log_id')->constrained()->cascadeOnDelete();
            $table->string('query_parameter');
            $table->timestamps();
        });

        Schema::create('request', function (Blueprint $table) {
            $table->id();
            $table->foreignId('log_id')->constrained()->cascadeOnDelete();
            $table->string('request_parameter');
            $table->timestamps();
        });

        Schema::create('cookie', function (Blueprint $table) {
            $table->id();
            $table->foreignId('log_id')->constrained()->cascadeOnDelete();
            $table->string('cookie_parameter');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('query');
        Schema::dropIfExists('request');
        Schema::dropIfExists('cookie');
    }
};